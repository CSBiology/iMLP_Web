If you would like to contribute a plugin, fix a bug or fix some horrible typo in the docs please submit a PR if you can, alternativly create an issue! Please note, while the code base doesn't follow any strict style, please try to ensure your PRs follow the general convention you see (there may be times the convention isn't followed, if you see this submit an issue/PR and slap me on the wrist :)). Any PR/issue at this time will not be rejected but may have some alternation to the code.

If you are submitting a plugin, please also submit the relevant documentation.
